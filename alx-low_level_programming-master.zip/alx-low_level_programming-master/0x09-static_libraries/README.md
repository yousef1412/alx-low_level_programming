my readme for 0x09-static_libraries
