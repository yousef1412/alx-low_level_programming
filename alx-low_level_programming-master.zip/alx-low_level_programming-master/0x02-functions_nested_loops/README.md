0x02. C - Functions, nested loops
